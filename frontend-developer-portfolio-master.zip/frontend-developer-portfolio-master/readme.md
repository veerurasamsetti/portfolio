This is my personal front-end developer portfolio that can be found on https://www.damiandrewnik.com

It has sections presenting my current skills and chosen projects.

Technologies used:
HTML
CSS
Sass
JavaScript
